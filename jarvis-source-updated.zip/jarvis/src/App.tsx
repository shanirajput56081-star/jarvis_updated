import { useState, useEffect, useRef } from "react";
import { ConnectionStatus, AssistantState, LogEntry } from "./types";
import { AudioStreamer } from "./lib/AudioStreamer";
import { JarvisCore } from "./components/JarvisCore";
import { HudDisplay } from "./components/HudDisplay";
import {
  Cpu,
  Wifi,
  WifiOff,
  RefreshCw,
  Radio,
  Mic,
  MicOff,
  Camera,
  ExternalLink,
  Copy,
  Check,
  Code,
  Terminal,
  Monitor,
  Sparkles
} from "lucide-react";

interface CodeBlockItem {
  id: string;
  type: "text" | "code";
  content: string;
  language?: string;
}

function parseMarkdownBlocks(text: string): CodeBlockItem[] {
  const parts: CodeBlockItem[] = [];
  const regex = /```(\w*)\n([\s\S]*?)```/g;
  let lastIndex = 0;
  let match;

  while ((match = regex.exec(text)) !== null) {
    const textBefore = text.substring(lastIndex, match.index);
    if (textBefore.trim()) {
      parts.push({
        id: Math.random().toString(36).substring(2, 9),
        type: "text",
        content: textBefore
      });
    }

    parts.push({
      id: Math.random().toString(36).substring(2, 9),
      type: "code",
      language: match[1] || "code",
      content: match[2].trim()
    });

    lastIndex = regex.lastIndex;
  }

  const remainingText = text.substring(lastIndex);
  if (remainingText.trim()) {
    parts.push({
      id: Math.random().toString(36).substring(2, 9),
      type: "text",
      content: remainingText
    });
  }

  return parts;
}

function getStreamingMarkdown(fullText: string, linesToShow: number): string {
  if (linesToShow === 0) return "";
  const lines = fullText.split("\n");
  if (lines.length <= 1 || linesToShow >= lines.length) {
    return fullText;
  }

  const slicedLines = lines.slice(0, linesToShow);
  let result = slicedLines.join("\n");

  // Check if a code block was started but not finished in the slice
  let backtickCount = 0;
  for (const line of slicedLines) {
    if (line.trim().startsWith("```")) {
      backtickCount++;
    }
  }

  // If there's an odd number of "```" lines, it means a code block is open and needs to be closed
  if (backtickCount % 2 !== 0) {
    result += "\n```";
  }

  return result;
}

export default function App() {
  // Connections and UI state
  const [status, setStatus] = useState<ConnectionStatus>("disconnected");
  const [assistantState, setAssistantState] = useState<AssistantState>("idle");
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isMuted, setIsMuted] = useState(false);
  const [audioEnergy, setAudioEnergy] = useState(0);
  const [lastOpenedUrl, setLastOpenedUrl] = useState<{ url: string; siteName: string; id: string } | null>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [codeSnipStream, setCodeSnipStream] = useState<string>("");
  const [isCodeEditorOpen, setIsCodeEditorOpen] = useState(false);
  const [codeSearch, setCodeSearch] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [copiedWorkspace, setCopiedWorkspace] = useState(false);
  const [isInIframe, setIsInIframe] = useState(false);
  const [currentFilename, setCurrentFilename] = useState<string>("jarvis_workspace.ts");
  const [displayedCodeStream, setDisplayedCodeStream] = useState<string>("");
  const [animatingLineCount, setAnimatingLineCount] = useState<number>(0);
  const animationTimerRef = useRef<any>(null);
  const codeWorkspaceRef = useRef<HTMLDivElement | null>(null);

  // Line-by-line code typing animation effect
  useEffect(() => {
    if (!codeSnipStream) {
      setDisplayedCodeStream("");
      setAnimatingLineCount(0);
      if (animationTimerRef.current) {
        clearInterval(animationTimerRef.current);
        animationTimerRef.current = null;
      }
      return;
    }

    const lines = codeSnipStream.split("\n");
    const totalLines = lines.length;

    // Clear any existing animation timer
    if (animationTimerRef.current) {
      clearInterval(animationTimerRef.current);
    }

    // Determine lines per step and interval based on code size
    // Max step is scaled so large files finish typing within ~2.5 seconds
    const linesPerStep = Math.max(1, Math.ceil(totalLines / 120));
    const intervalMs = totalLines < 25 ? 60 : 20;

    let currentLine = 0;
    setAnimatingLineCount(0);
    setDisplayedCodeStream(getStreamingMarkdown(codeSnipStream, 0));

    animationTimerRef.current = setInterval(() => {
      currentLine += linesPerStep;
      if (currentLine >= totalLines) {
        currentLine = totalLines;
        clearInterval(animationTimerRef.current);
        animationTimerRef.current = null;
      }
      setAnimatingLineCount(currentLine);
      setDisplayedCodeStream(getStreamingMarkdown(codeSnipStream, currentLine));
    }, intervalMs);

    return () => {
      if (animationTimerRef.current) {
        clearInterval(animationTimerRef.current);
      }
    };
  }, [codeSnipStream]);

  // Auto-scroll the code viewport to the bottom as new lines type out
  useEffect(() => {
    const el = codeWorkspaceRef.current;
    if (el) {
      // Scroll immediately
      el.scrollTop = el.scrollHeight;

      // Also scroll after a slight delay to ensure layout rendering has updated the scroll height
      const timer = setTimeout(() => {
        el.scrollTop = el.scrollHeight;
      }, 50);

      return () => clearTimeout(timer);
    }
  }, [displayedCodeStream]);

  useEffect(() => {
    setIsInIframe(window.self !== window.top);
  }, []);

  // Auto-open code editor when code transmissions start
  useEffect(() => {
    if (codeSnipStream && codeSnipStream.trim().length > 0) {
      setIsCodeEditorOpen(true);
    }
  }, [codeSnipStream]);

  // References
  const wsRef = useRef<WebSocket | null>(null);
  const audioStreamerRef = useRef<AudioStreamer | null>(null);
  const isMutedRef = useRef(isMuted);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);
  const screenVideoRef = useRef<HTMLVideoElement | null>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);

  // Sync mute state ref to prevent stale closures in callbacks
  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  const speakingTimeoutRef = useRef<any>(null);
  const assistantStateRef = useRef<AssistantState>(assistantState);

  // Sync assistantStateRef to prevent stale closures in capture loops
  useEffect(() => {
    assistantStateRef.current = assistantState;
  }, [assistantState]);

  // Push helper to add logs with timestamp
  const addLog = (type: LogEntry["type"], message: string, meta?: any) => {
    const time = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    const id = Math.random().toString(36).substring(2, 9);
    setLogs((prev) => [...prev, { id, time, type, message, meta }]);
  };

  // Connect / Disconnect Jarvis Core Voice Session
  const toggleConnection = async () => {
    if (status === "connected" || status === "connecting") {
      disconnectSession();
    } else {
      await connectSession();
    }
  };

  const connectSession = async () => {
    try {
      setStatus("connecting");
      setAssistantState("connecting");
      addLog("system", "Initializing Jarvis Bidi core systems...");

      // 1. Initialize audio streamer
      const streamer = new AudioStreamer((base64Audio) => {
        // Send recorded user speech audio PCM16 base64 to server
        if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN && !isMutedRef.current) {
          wsRef.current.send(
            JSON.stringify({
              type: "audio",
              audio: base64Audio,
            })
          );
        }
      });
      audioStreamerRef.current = streamer;

      // 2. Establish custom server WebSocket
      // Uses VITE_BACKEND_WS_URL if set (e.g. wss://your-backend.up.railway.app/live)
      // so the frontend can be hosted separately (e.g. on cPanel) from the
      // Node/WebSocket backend (which needs a host that supports persistent
      // Node processes, unlike shared PHP-only cPanel hosting).
      const configuredWsUrl = import.meta.env.VITE_BACKEND_WS_URL as string | undefined;
      let wsUrl: string;
      if (configuredWsUrl && configuredWsUrl.trim() !== "") {
        wsUrl = configuredWsUrl.trim();
      } else {
        const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
        wsUrl = `${protocol}//${window.location.host}/live`;
      }
      addLog("system", `Routing bridge matrix connection to ${wsUrl}`);

      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        addLog("system", "Sub-space bridge established successfully.");
      };

      ws.onmessage = async (event) => {
        try {
          const data = JSON.parse(event.data);

          // Handle server-established state
          if (data.type === "connected") {
            setStatus("connected");
            setAssistantState("speaking"); // Model immediately outputs the first Hinglish greeting
            addLog("system", "Jarvis Neural link ONLINE. Secure voice channel secured.");
            
            // Start recording user's microphone
            await streamer.startRecording();
            addLog("system", "Sensing user microphone array [16kHz PCM]...");

            // Reset talking state back to listening after the first greeting
            if (speakingTimeoutRef.current) {
              clearTimeout(speakingTimeoutRef.current);
            }
            speakingTimeoutRef.current = setTimeout(() => {
              if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
                setAssistantState("listening");
              } else {
                setAssistantState("idle");
              }
            }, 3000); // Give the initial greeting 3 seconds
          }

          // Handle incoming assistant voice stream chunks
          else if (data.type === "audio" && data.audio) {
            setAssistantState("speaking");
            streamer.playAudioChunk(data.audio);

            // Debounce state transition back to listening
            if (speakingTimeoutRef.current) {
              clearTimeout(speakingTimeoutRef.current);
            }
            speakingTimeoutRef.current = setTimeout(() => {
              if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
                setAssistantState("listening");
              } else {
                setAssistantState("idle");
              }
            }, 1500); // 1.5 seconds of no audio chunks means Jarvis is done speaking
          }

          // Handle user speaking interruption detected by model
          else if (data.type === "interrupted") {
            addLog("system", "User intervention detected. Flushing scheduled playback nodes.");
            streamer.handleInterruption();
            setAssistantState("listening");
            
            if (speakingTimeoutRef.current) {
              clearTimeout(speakingTimeoutRef.current);
              speakingTimeoutRef.current = null;
            }
          }

          // Handle incoming assistant text transcription / code snippets
          else if (data.type === "text" && data.text) {
            setCodeSnipStream((prev) => prev + data.text);
          }

          // Handle function calling / toolCall request
          else if (data.type === "toolCall") {
            const toolCall = data.toolCall;
            if (toolCall?.functionCalls) {
              for (const fn of toolCall.functionCalls) {
                if (fn.name === "openWebsite") {
                  const url = fn.args?.url;
                  const siteName = fn.args?.siteName || "Requested Website";
                  addLog("tool", `Executing browser operation 'openWebsite' for ${siteName} (${url})`);

                  // Attempt window.open natively
                  try {
                    window.open(url, "_blank");
                  } catch (e) {
                    console.warn("Popup blocker warning inside iframe:", e);
                  }

                  // Provide manual visual button overlay fallback in HUD
                  setLastOpenedUrl({ url, siteName, id: fn.id });

                  // Report back instantly to Gemini Live
                  ws.send(
                    JSON.stringify({
                      type: "toolResponse",
                      id: fn.id,
                      name: fn.name,
                      response: {
                        output: {
                          success: true,
                          message: `Opened ${siteName} successfully in a new browser tab.`,
                        },
                      },
                    })
                  );
                  addLog("tool", `Tool response sent back to neural core. id: ${fn.id}`);
                }

                else if (fn.name === "displayCode") {
                  const code = fn.args?.code;
                  const language = fn.args?.language || "typescript";
                  const filename = fn.args?.filename || "jarvis_workspace.ts";
                  addLog("tool", `Executing displayCode operation for file '${filename}'`);

                  // Wrap the code block in markdown format for our parser
                  const markdownBlock = `\`\`\`${language}\n${code}\n\`\`\``;
                  setCurrentFilename(filename);
                  setCodeSnipStream(markdownBlock);
                  setIsCodeEditorOpen(true);

                  // Send response back
                  ws.send(
                    JSON.stringify({
                      type: "toolResponse",
                      id: fn.id,
                      name: fn.name,
                      response: {
                        output: {
                          success: true,
                          message: `Displayed code block successfully under filename '${filename}' inside the user's workspace.`,
                        },
                      },
                    })
                  );
                  addLog("tool", `Code workspace populated with '${filename}' and reported back to neural core.`);
                }
              }
            }
          }

          // Handle session termination / errors
          else if (data.type === "closed") {
            addLog("system", "Sub-space link closed by neural node.");
            disconnectSession();
          } else if (data.type === "error") {
            setStatus("error");
            setAssistantState("idle");
            addLog("system", `Neural node diagnostic error: ${data.error}`);
          }
        } catch (err: any) {
          console.error("Error processing WebSocket packet:", err);
        }
      };

      ws.onerror = (err) => {
        console.error("Local WebSocket connection error:", err);
        setStatus("error");
        setAssistantState("idle");
        addLog("system", "Sub-space matrix routing handshake failed.");
      };

      ws.onclose = () => {
        addLog("system", "Neural link routing deactivated.");
        disconnectSession();
      };

    } catch (err: any) {
      console.error("Failed to establish voice session:", err);
      setStatus("error");
      setAssistantState("idle");
      addLog("system", `System boot failure: ${err.message || err}`);
      disconnectSession();
    }
  };

  const disconnectSession = () => {
    addLog("system", "Terminating core neural link... Standby.");
    setIsCameraOpen(false);
    setIsScreenSharing(false);
    
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }

    if (audioStreamerRef.current) {
      audioStreamerRef.current.destroy();
      audioStreamerRef.current = null;
    }

    if (speakingTimeoutRef.current) {
      clearTimeout(speakingTimeoutRef.current);
      speakingTimeoutRef.current = null;
    }

    setStatus("disconnected");
    setAssistantState("idle");
    setLastOpenedUrl(null);
    addLog("system", "Jarvis core powered down to STANDBY.");
  };

  // Manage video stream connection
  useEffect(() => {
    let captureInterval: any;

    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: 320, height: 240 },
        });
        cameraStreamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        addLog("system", "Neural camera optic feed ENGAGED.");
      } catch (err) {
        console.error("Error starting camera:", err);
        setIsCameraOpen(false);
      }
    };

    if (isCameraOpen && status === "connected") {
      startCamera();

      // Set up frame capture loop at 1 FPS
      captureInterval = setInterval(() => {
        // Prevent sending video frames while Jarvis is speaking to avoid interrupting the speech playback
        if (assistantStateRef.current === "speaking") {
          return;
        }

        if (videoRef.current && wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
          const video = videoRef.current;
          if (video.readyState === video.HAVE_ENOUGH_DATA) {
            const canvas = document.createElement("canvas");
            canvas.width = 320;
            canvas.height = 240;
            const ctx = canvas.getContext("2d");
            if (ctx) {
              ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
              const dataUrl = canvas.toDataURL("image/jpeg", 0.5); // 0.5 quality for performance
              const base64Data = dataUrl.split(",")[1];
              if (base64Data) {
                wsRef.current.send(
                  JSON.stringify({
                    type: "video",
                    video: base64Data,
                  })
                );
              }
            }
          }
        }
      }, 1000); // 1 FPS
    } else {
      // If camera closed or disconnected
      if (cameraStreamRef.current) {
        cameraStreamRef.current.getTracks().forEach((track) => track.stop());
        cameraStreamRef.current = null;
      }
      if (videoRef.current) {
        videoRef.current.srcObject = null;
      }
    }

    return () => {
      if (captureInterval) clearInterval(captureInterval);
    };
  }, [isCameraOpen, status]);

  // Manage screen share connection
  useEffect(() => {
    let captureInterval: any;

    const startScreenShare = async () => {
      try {
        const stream = await navigator.mediaDevices.getDisplayMedia({
          video: { width: 640, height: 480, frameRate: 5 },
          audio: false
        });
        screenStreamRef.current = stream;
        if (screenVideoRef.current) {
          screenVideoRef.current.srcObject = stream;
        }
        addLog("system", "Neural screen-share optics link ESTABLISHED.");

        // Proactively wake up/resume audio contexts since browser screen-sharing popup shifts focus and suspends Web Audio
        if (audioStreamerRef.current) {
          await audioStreamerRef.current.resumeAudioContexts();
          
          // Retry after a small delay once browser window focus stabilizes
          setTimeout(() => {
            audioStreamerRef.current?.resumeAudioContexts();
          }, 500);
          setTimeout(() => {
            audioStreamerRef.current?.resumeAudioContexts();
          }, 1500);
        }

        // Listen for when the user clicks browser's built-in 'Stop sharing' button
        stream.getVideoTracks()[0].onended = () => {
          setIsScreenSharing(false);
          addLog("system", "Screen share feed disconnected by user.");
        };
      } catch (err: any) {
        console.error("Error starting screen share:", err);
        setIsScreenSharing(false);
        
        const errMsg = (err.message || "").toLowerCase();
        if (errMsg.includes("permissions policy") || errMsg.includes("disallowed") || errMsg.includes("not allowed")) {
          addLog("system", "⚠️ IFRAME SECURITY LIMITATION: Browser ne AI Studio frame sandbox ke andar screen-sharing block kiya hai.");
          addLog("system", "💡 SOLUTION: Isko sahi karne ke liye screen ke top-right corner par glowing 'OPEN NEW TAB' button par click karein! Naye tab me full system permissions available hain.");
        } else {
          addLog("system", `Failed to establish screen link: ${err.message || err}`);
        }
      }
    };

    if (isScreenSharing && status === "connected") {
      startScreenShare();

      // Set up frame capture loop at 1 FPS
      captureInterval = setInterval(() => {
        // Prevent sending video frames while Jarvis is speaking to avoid interrupting the speech playback
        if (assistantStateRef.current === "speaking") {
          return;
        }

        if (screenVideoRef.current && wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
          const video = screenVideoRef.current;
          if (video.readyState === video.HAVE_ENOUGH_DATA) {
            const canvas = document.createElement("canvas");
            // Capture screen share at 640x480 for much better text/code readability
            canvas.width = 640;
            canvas.height = 480;
            const ctx = canvas.getContext("2d");
            if (ctx) {
              ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
              const dataUrl = canvas.toDataURL("image/jpeg", 0.55); // 0.55 quality for readability and performance
              const base64Data = dataUrl.split(",")[1];
              if (base64Data) {
                wsRef.current.send(
                  JSON.stringify({
                    type: "video",
                    video: base64Data,
                  })
                );
              }
            }
          }
        }
      }, 1000); // 1 FPS
    } else {
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach((track) => track.stop());
        screenStreamRef.current = null;
      }
      if (screenVideoRef.current) {
        screenVideoRef.current.srcObject = null;
      }
    }

    return () => {
      if (captureInterval) clearInterval(captureInterval);
    };
  }, [isScreenSharing, status]);

  // Run dynamic hardware telemetry for audio waveform rings
  useEffect(() => {
    let animationFrameId: number;

    const updateVolumeGlow = () => {
      if (audioStreamerRef.current) {
        let energy = 0;
        if (assistantState === "listening" && !isMuted) {
          energy = audioStreamerRef.current.getInputVolume();
        } else if (assistantState === "speaking") {
          energy = audioStreamerRef.current.getOutputVolume();
        }
        setAudioEnergy(energy);
      }
      animationFrameId = requestAnimationFrame(updateVolumeGlow);
    };

    animationFrameId = requestAnimationFrame(updateVolumeGlow);
    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [assistantState, isMuted]);

  // Teardown connection on unmount
  useEffect(() => {
    return () => {
      if (wsRef.current) wsRef.current.close();
      if (audioStreamerRef.current) audioStreamerRef.current.destroy();
    };
  }, []);

  return (
    <main className="min-h-screen bg-[#020617] text-slate-100 flex flex-col items-center p-4 md:p-8 selection:bg-cyan-500/30 selection:text-white relative overflow-hidden" id="jarvis-app-container">
      {/* Geometric Balance Theme Overlays */}
      <div className="hud-grid" />
      <div className="scanline" style={{ top: "15%" }} />
      <div className="corner-l tl" />
      <div className="corner-l tr" />
      <div className="corner-l bl" />
      <div className="corner-l br" />

      {/* Immersive HUD Glowing Top Bar */}
      <header className="w-full max-w-5xl flex items-center justify-between border-b border-sky-500/10 pb-4 mb-6 z-10" id="hud-header">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Radio className="w-6 h-6 text-cyan-400 animate-pulse" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-widest text-slate-100 font-mono flex items-center gap-2">
              <span>JARVIS</span>
              <span className="text-cyan-400 text-xs font-semibold px-1.5 py-0.5 rounded border border-cyan-500/20 bg-cyan-950/20">
                LIVE VOICE
              </span>
            </h1>
            <p className="text-[10px] text-slate-500 font-mono tracking-tight uppercase">
              Autonomous Quantum Bidi Intelligence
            </p>
          </div>
        </div>

        {/* HUD System Clock & Connectivity */}
        <div className="flex items-center gap-3 text-[11px] font-mono text-slate-400">
          {isInIframe && (
            <button
              onClick={() => window.open(window.location.href, "_blank")}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded border border-cyan-500/30 bg-cyan-950/40 text-cyan-400 hover:bg-cyan-400 hover:text-slate-950 transition-all cursor-pointer font-bold animate-pulse shadow-[0_0_8px_rgba(0,217,255,0.2)]"
              id="hud-header-newtab-btn"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>OPEN NEW TAB</span>
            </button>
          )}

          <div className="hidden sm:flex items-center gap-2 border border-slate-800/80 px-2.5 py-1 rounded bg-slate-900/30">
            <Cpu className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-slate-500">SESSION ID:</span>
            <span className="text-cyan-400 font-semibold uppercase animate-pulse">XV-992-JARVIS</span>
          </div>

          <button
            onClick={() => setIsCodeEditorOpen((prev) => !prev)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded border transition-all cursor-pointer font-bold font-mono text-[11px] ${
              isCodeEditorOpen
                ? "border-cyan-500 bg-cyan-950/40 text-cyan-400 shadow-[0_0_8px_rgba(0,217,255,0.2)] animate-pulse"
                : "border-slate-800 bg-slate-900/30 text-slate-400 hover:text-slate-200"
            }`}
            id="hud-header-code-editor-btn"
            title="Toggle Live Code IDE Popup"
          >
            <Code className="w-3.5 h-3.5" />
            <span>CODE WORKSPACE</span>
          </button>

          <div className="flex items-center gap-2 border border-slate-800/80 px-2.5 py-1 rounded bg-slate-900/30">
            {status === "connected" ? (
              <>
                <Wifi className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-cyan-400 font-semibold uppercase">SECURED</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3.5 h-3.5 text-slate-500" />
                <span className="text-slate-500 uppercase">STANDBY</span>
              </>
            ) }
          </div>
        </div>
      </header>

      {/* Main Container */}
      <div className="w-full max-w-5xl flex-1 flex flex-col items-center justify-between gap-8 z-10" id="hud-workspace">
        {/* Core Display Center */}
        <div className="flex-1 w-full flex items-center justify-center py-6" id="hud-core-column">
          <JarvisCore
            status={status}
            state={assistantState}
            onClick={toggleConnection}
            audioEnergy={audioEnergy}
          />
        </div>

        {/* Controls Overlay and Bottom Diagnostic Deck */}
        <div className="w-full flex flex-col gap-6" id="hud-diagnostic-column">
          <div className="flex flex-wrap justify-center gap-4 items-center" id="hud-control-deck">
            {/* Boot/Terminate Connection */}
            <button
              onClick={toggleConnection}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-md border font-semibold tracking-wider font-mono text-xs transition-all cursor-pointer ${
                status === "connected"
                  ? "border-red-500/30 bg-red-950/30 hover:bg-red-900/40 text-red-300 hover:text-red-200"
                  : status === "connecting"
                  ? "border-cyan-500/50 bg-cyan-950/30 text-cyan-400 animate-pulse cursor-wait"
                  : "border-cyan-500 bg-cyan-950/40 hover:bg-cyan-500 hover:text-slate-950 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.2)]"
              }`}
            >
              <RefreshCw className={`w-4 h-4 ${status === "connecting" ? "animate-spin" : ""}`} />
              <span>
                {status === "connected"
                  ? "TERMINATE JARVIS COUPLING"
                  : status === "connecting"
                  ? "INITIALIZING QUANTUM BRIDGE..."
                  : "BOOT JARVIS CORE SESSION"}
              </span>
            </button>

            {/* Mic Toggle Button */}
            <button
              onClick={() => setIsMuted((prev) => !prev)}
              disabled={status !== "connected"}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-md border font-semibold tracking-wider font-mono text-xs transition-all ${
                status !== "connected"
                  ? "border-slate-800 bg-slate-950/20 text-slate-600 cursor-not-allowed"
                  : isMuted
                  ? "border-red-500/50 bg-red-950/40 text-red-400 hover:bg-red-900/40 cursor-pointer shadow-[0_0_10px_rgba(239,68,68,0.2)]"
                  : "border-emerald-500/50 bg-emerald-950/30 text-emerald-400 hover:bg-emerald-900/20 cursor-pointer shadow-[0_0_10px_rgba(16,185,129,0.2)]"
              }`}
              title={isMuted ? "Unmute Mic Input" : "Mute Mic Input"}
            >
              {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              <span>{isMuted ? "MIC MUTED" : "MIC ACTIVE"}</span>
            </button>

            {/* Camera Toggle Button */}
            <button
              onClick={() => setIsCameraOpen((prev) => !prev)}
              disabled={status !== "connected"}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-md border font-semibold tracking-wider font-mono text-xs transition-all ${
                status !== "connected"
                  ? "border-slate-800 bg-slate-950/20 text-slate-600 cursor-not-allowed"
                  : isCameraOpen
                  ? "border-cyan-500/80 bg-cyan-950/50 text-cyan-400 hover:bg-cyan-900/30 cursor-pointer shadow-[0_0_12px_rgba(0,217,255,0.3)]"
                  : "border-slate-700 bg-slate-900/40 text-slate-300 hover:bg-slate-800/60 cursor-pointer"
              }`}
              title={isCameraOpen ? "Close Camera" : "Open Camera"}
            >
              <Camera className="w-4 h-4" />
              <span>{isCameraOpen ? "CAMERA OPEN" : "CAMERA CLOSED"}</span>
            </button>

            {/* Screen Share Toggle Button */}
            <button
              onClick={() => setIsScreenSharing((prev) => !prev)}
              disabled={status !== "connected"}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-md border font-semibold tracking-wider font-mono text-xs transition-all ${
                status !== "connected"
                  ? "border-slate-800 bg-slate-950/20 text-slate-600 cursor-not-allowed"
                  : isScreenSharing
                  ? "border-emerald-500/80 bg-emerald-950/50 text-emerald-400 hover:bg-emerald-900/30 cursor-pointer shadow-[0_0_12px_rgba(16,185,129,0.3)]"
                  : "border-slate-700 bg-slate-900/40 text-slate-300 hover:bg-slate-800/60 cursor-pointer"
              }`}
              title={isScreenSharing ? "Stop Screen Share" : "Share Screen"}
            >
              <Monitor className="w-4 h-4" />
              <span>{isScreenSharing ? "SCREEN LINK OPEN" : "SCREEN SHARE CLOSED"}</span>
            </button>

            {/* Code Workspace Toggle Button */}
            <button
              onClick={() => setIsCodeEditorOpen((prev) => !prev)}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-md border font-semibold tracking-wider font-mono text-xs transition-all cursor-pointer ${
                isCodeEditorOpen
                  ? "border-cyan-500 bg-cyan-950/40 text-cyan-400 hover:bg-cyan-900/20 shadow-[0_0_12px_rgba(0,217,255,0.3)]"
                  : "border-slate-700 bg-slate-900/40 text-slate-300 hover:bg-slate-800/60"
              }`}
              title="Toggle Live Code IDE Workspace Window"
            >
              <Code className="w-4 h-4" />
              <span>{isCodeEditorOpen ? "CODE WORKSPACE OPEN" : "CODE WORKSPACE CLOSED"}</span>
            </button>

            {/* Launch Standalone in New Tab */}
            <button
              onClick={() => window.open(window.location.href, "_blank")}
              className="flex items-center gap-2 px-5 py-2.5 rounded-md border border-cyan-500/30 bg-slate-900/40 text-cyan-300 hover:bg-cyan-500 hover:text-slate-950 transition-all cursor-pointer shadow-[0_0_15px_rgba(0,217,255,0.15)] font-mono text-xs font-semibold tracking-wider"
              title="Launch Jarvis in Dedicated Standalone Tab"
              id="hud-launch-tab-button"
            >
              <ExternalLink className="w-4 h-4" />
              <span>LAUNCH STANDALONE TAB</span>
            </button>
          </div>

          <HudDisplay
            status={status}
            state={assistantState}
            lastOpenedUrl={lastOpenedUrl}
          />
        </div>
      </div>

      {/* Floating Webcam Preview Popup */}
      {isCameraOpen && status === "connected" && (
        <div
          className="fixed bottom-6 right-6 z-50 w-[240px] border-2 border-cyan-500/50 bg-slate-950/90 rounded-lg shadow-[0_0_20px_rgba(0,217,255,0.25)] overflow-hidden font-mono text-[10px]"
          id="camera-preview-popup"
        >
          {/* Header of the camera popup */}
          <div className="flex items-center justify-between bg-slate-900 px-3 py-1.5 border-b border-cyan-500/20 text-slate-300">
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
              <span className="font-bold tracking-wider text-[9px] text-cyan-400">JARVIS CORE VISION</span>
            </div>
            <button
              onClick={() => setIsCameraOpen(false)}
              className="text-slate-500 hover:text-cyan-400 font-bold px-1 rounded transition-all cursor-pointer"
              title="Close Camera"
            >
              ✕
            </button>
          </div>

          {/* Video preview display */}
          <div className="relative w-full aspect-video bg-black flex items-center justify-center overflow-hidden">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover scale-x-[-1]"
            />
            {/* Holographic scanner overlay */}
            <div className="absolute inset-0 bg-[radial-gradient(transparent_50%,rgba(0,217,255,0.08)_100%)] pointer-events-none" />
            <div className="absolute top-1 left-2 text-[8px] text-cyan-400/70 select-none">
              FEED: REC [1.0 FPS]
            </div>
            <div className="absolute top-1 right-2 text-[8px] text-cyan-400/70 select-none">
              320x240 px
            </div>
            {/* Moving laser scanline inside video */}
            <div className="absolute left-0 w-full h-[1px] bg-cyan-400/40 opacity-55 animate-pulse" style={{ top: "40%" }} />
          </div>
        </div>
      )}

      {/* Floating Screen Share Preview Popup */}
      {isScreenSharing && status === "connected" && (
        <div
          className="fixed bottom-6 left-6 z-50 w-[260px] border-2 border-emerald-500/50 bg-slate-950/95 rounded-lg shadow-[0_0_20px_rgba(16,185,129,0.25)] overflow-hidden font-mono text-[10px]"
          id="screen-preview-popup"
        >
          {/* Header of the screen popup */}
          <div className="flex items-center justify-between bg-slate-900 px-3 py-1.5 border-b border-emerald-500/20 text-slate-300">
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-bold tracking-wider text-[9px] text-emerald-400">JARVIS CORE SCREEN LINK</span>
            </div>
            <button
              onClick={() => setIsScreenSharing(false)}
              className="text-slate-500 hover:text-emerald-400 font-bold px-1 rounded transition-all cursor-pointer"
              title="Stop Sharing"
            >
              ✕
            </button>
          </div>

          {/* Video preview display */}
          <div className="relative w-full aspect-video bg-black flex items-center justify-center overflow-hidden">
            <video
              ref={screenVideoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-contain"
            />
            {/* Holographic scanner overlay */}
            <div className="absolute inset-0 bg-[radial-gradient(transparent_50%,rgba(16,185,129,0.06)_100%)] pointer-events-none" />
            <div className="absolute top-1 left-2 text-[8px] text-emerald-400/80 select-none">
              FEED: LINKED [1.0 FPS]
            </div>
            <div className="absolute top-1 right-2 text-[8px] text-emerald-400/80 select-none">
              640x480 px
            </div>
            {/* Moving laser scanline inside video */}
            <div className="absolute left-0 w-full h-[1px] bg-emerald-500/30 opacity-40 animate-pulse" style={{ top: "60%" }} />
          </div>
        </div>
      )}

      {/* Floating Code Editor Workspace Popup */}
      {isCodeEditorOpen && (
        <div
          className="fixed inset-x-4 md:inset-x-auto md:right-8 bottom-6 md:w-[650px] h-[550px] bg-[#030712]/95 border-2 border-cyan-500/30 rounded-xl shadow-[0_0_50px_rgba(0,217,255,0.18)] flex flex-col z-50 backdrop-blur-md overflow-hidden font-mono text-xs select-text animate-in fade-in slide-in-from-bottom-5 duration-300"
          id="code-workspace-popup"
        >
          {/* Editor Header / IDE Tab Bar */}
          <div className="flex items-center justify-between bg-slate-950 px-4 py-2 border-b border-cyan-500/20 text-slate-300 select-none">
            <div className="flex items-center gap-3">
              {/* VS Code styled tab buttons */}
              <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-900 border-t-2 border-cyan-400 rounded-t-md text-cyan-400 text-[10px] font-bold font-mono">
                <Code className="w-3.5 h-3.5 text-cyan-400" />
                <span>{currentFilename}</span>
              </div>
              <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 text-slate-500 text-[10px] font-mono hover:text-slate-300 transition-all cursor-pointer">
                <Terminal className="w-3.5 h-3.5" />
                <span>neural_bridge.log</span>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              {codeSnipStream && (
                <>
                  <button
                    onClick={() => {
                      const blocks = parseMarkdownBlocks(codeSnipStream);
                      const codeBlocks = blocks.filter(b => b.type === "code");
                      const textToCopy = codeBlocks.length > 0 
                        ? codeBlocks.map(b => b.content).join("\n\n") 
                        : codeSnipStream;
                      
                      navigator.clipboard.writeText(textToCopy);
                      setCopiedWorkspace(true);
                      setTimeout(() => setCopiedWorkspace(false), 2000);
                    }}
                    className="flex items-center gap-1 font-mono text-[9px] px-2 py-0.5 border border-cyan-500/30 hover:border-cyan-500/60 bg-cyan-950/20 hover:bg-cyan-950/40 text-cyan-400 rounded transition-all cursor-pointer uppercase font-bold"
                    title="Copy full code in this workspace"
                  >
                    {copiedWorkspace ? (
                      <>
                        <Check className="w-2.5 h-2.5 text-cyan-400" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-2.5 h-2.5 text-cyan-400" />
                        <span>Copy Code</span>
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => {
                      setCodeSnipStream("");
                      addLog("system", "Neural transcription buffer cleared.");
                    }}
                    className="font-mono text-[9px] px-2 py-0.5 border border-red-500/30 hover:border-red-500/60 bg-red-950/20 hover:bg-red-950/40 text-red-400 rounded transition-all cursor-pointer uppercase font-bold"
                  >
                    Clear
                  </button>
                </>
              )}
              <button
                onClick={() => setIsCodeEditorOpen(false)}
                className="text-slate-400 hover:text-cyan-400 font-bold px-1.5 py-0.5 rounded transition-all cursor-pointer text-sm"
                title="Minimize Code Workspace"
              >
                ✕
              </button>
            </div>
          </div>

          {/* IDE Search / Action Toolbar */}
          <div className="flex items-center gap-3 px-4 py-2 bg-slate-900/45 border-b border-cyan-500/10 justify-between">
            <div className="flex items-center gap-2 flex-1 max-w-[280px]">
              <span className="text-[10px] text-cyan-500 font-bold uppercase select-none">FIND:</span>
              <input
                type="text"
                value={codeSearch}
                onChange={(e) => setCodeSearch(e.target.value)}
                placeholder="Search words inside code..."
                className="w-full bg-black/60 border border-slate-800 focus:border-cyan-500/50 px-2 py-0.5 rounded text-[10px] text-cyan-300 font-mono outline-none placeholder:text-slate-600"
              />
            </div>
            <div className="font-sans text-[10px] text-slate-500 uppercase select-none tracking-wider">
              JARVIS LIVE SYNCHRONIZER
            </div>
          </div>

          {/* Code Viewer Workspace */}
          <div ref={codeWorkspaceRef} className="flex-1 p-4 overflow-y-auto font-mono text-xs text-slate-300 space-y-4 custom-scrollbar bg-slate-950/40">
            {displayedCodeStream ? (
              parseMarkdownBlocks(displayedCodeStream).map((block, idx) => {
                if (block.type === "code") {
                  // Filter content if search query is entered
                  if (codeSearch && !block.content.toLowerCase().includes(codeSearch.toLowerCase())) {
                    return null;
                  }

                  const codeLines = block.content.split("\n");

                  return (
                    <div key={block.id || idx} className="border border-cyan-500/20 rounded-md bg-[#010409] shadow-lg overflow-hidden my-2">
                      {/* Block Header */}
                      <div className="flex items-center justify-between bg-slate-900/65 px-4 py-1.5 border-b border-cyan-500/15 text-[10px] text-cyan-300 font-semibold tracking-wider uppercase select-none">
                        <div className="flex items-center gap-1.5">
                          <Code className="w-3.5 h-3.5 text-cyan-400" />
                          <span>{block.language || "CODEBLOCK"}</span>
                          <span className="text-[8px] text-slate-500 font-normal">({codeLines.length} lines)</span>
                        </div>
                        <button
                          onClick={() => {
                            navigator.clipboard.writeText(block.content);
                            setCopiedId(block.id);
                            setTimeout(() => setCopiedId(null), 2000);
                          }}
                          className="flex items-center gap-1 px-2.5 py-0.5 rounded border border-cyan-500/30 hover:bg-cyan-400 hover:text-slate-950 transition-all cursor-pointer font-bold uppercase text-[9px]"
                        >
                          {copiedId === block.id ? (
                            <>
                              <Check className="w-3 h-3 text-slate-950" />
                              <span>COPIED!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>COPY FILE</span>
                            </>
                          )}
                        </button>
                      </div>
                      
                      {/* Interactive Code Editor Viewer with real line numbers */}
                      <div className="flex font-mono text-[11px] leading-relaxed select-text bg-black/40 p-4 overflow-x-auto custom-scrollbar">
                        {/* Simulated Line Numbers gutter */}
                        <div className="text-slate-600 pr-3.5 text-right select-none border-r border-slate-800/80 mr-3.5 min-w-[24px]">
                          {codeLines.map((_, i) => (
                            <div key={i} className="h-5">{i + 1}</div>
                          ))}
                        </div>
                        {/* Actual Code context with copy support */}
                        <pre className="flex-1 text-emerald-300/95 font-mono whitespace-pre select-text">
                          {codeLines.map((line, i) => (
                            <div key={i} className="h-5 hover:bg-cyan-500/5 transition-all px-1 rounded">{line}</div>
                          ))}
                        </pre>
                      </div>
                    </div>
                  );
                } else {
                  // Only display text blocks if they contain searched words too or search is empty
                  if (codeSearch && !block.content.toLowerCase().includes(codeSearch.toLowerCase())) {
                    return null;
                  }
                  return (
                    <div key={block.id || idx} className="leading-relaxed border-l-2 border-slate-700 pl-3 text-slate-300 select-text font-sans text-sm py-1">
                      <p className="whitespace-pre-wrap">{block.content}</p>
                    </div>
                  );
                }
              })
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center py-16 text-slate-500">
                <div className="relative mb-3">
                  <Sparkles className="w-8 h-8 text-slate-700 animate-pulse" />
                </div>
                <p className="text-xs font-semibold tracking-wider font-mono uppercase mb-1">Quantum Workspace Idle</p>
                <p className="text-[10px] max-w-xs font-sans text-slate-400">
                  Ask JARVIS to write code or script. The full text formatting and copy-ready syntax highlights will sync here inside this floating workspace!
                </p>
              </div>
            )}
          </div>

          {/* IDE Bottom Status Bar */}
          <div className="border-t border-cyan-500/10 px-4 py-1.5 bg-slate-950 flex justify-between items-center text-[9px] font-mono text-slate-500 uppercase tracking-widest select-none">
            <div className="flex items-center gap-3">
              <span className="text-cyan-500 font-semibold">
                STATUS: {!codeSnipStream ? "BRIDGE_STABLE" : animatingLineCount < codeSnipStream.split("\n").length ? "WRITING_CODE..." : "SYNC_ACTIVE"}
              </span>
              <span className="hidden sm:inline">| CHARSET: UTF-8</span>
            </div>
            <div className="flex items-center gap-3">
              <span>LINES: {displayedCodeStream ? displayedCodeStream.split("\n").length : 0} / {codeSnipStream ? codeSnipStream.split("\n").length : 0}</span>
              <span className="text-cyan-500">TYPESCRIPT</span>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
