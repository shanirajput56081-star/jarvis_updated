export class AudioStreamer {
  private inputAudioCtx: AudioContext | null = null;
  private outputAudioCtx: AudioContext | null = null;
  private micStream: MediaStream | null = null;
  private micSource: MediaStreamAudioSourceNode | null = null;
  private scriptProcessor: ScriptProcessorNode | null = null;
  private inputAnalyser: AnalyserNode | null = null;
  private outputAnalyser: AnalyserNode | null = null;

  private nextPlayTime: number = 0;
  private scheduledSources: AudioBufferSourceNode[] = [];

  private onInputAudio: (base64PCM16: string) => void;

  constructor(onInputAudio: (base64PCM16: string) => void) {
    this.onInputAudio = onInputAudio;
  }

  /**
   * Start recording microphone input at 16kHz mono and convert to PCM 16-bit base64.
   */
  public async startRecording() {
    try {
      this.stopRecording();

      // Setup 16kHz audio context for recording
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.inputAudioCtx = new AudioContextClass({ sampleRate: 16000 });

      // Listen for browser-triggered suspension (extremely common during focus shifts or media state changes)
      this.inputAudioCtx.onstatechange = () => {
        if (this.inputAudioCtx && this.inputAudioCtx.state === "suspended") {
          console.warn("Neural sensing AudioContext suspended. Auto-resuming...");
          this.inputAudioCtx.resume().catch((err) => console.error("Failed to auto-resume input context:", err));
        }
      };

      this.micStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      // Log/track any track-level mute changes
      this.micStream.getAudioTracks().forEach((track) => {
        track.onmute = () => console.warn("Microphone track muted by system.");
        track.onunmute = () => console.log("Microphone track unmuted.");
      });

      this.micSource = this.inputAudioCtx.createMediaStreamSource(this.micStream);
      this.inputAnalyser = this.inputAudioCtx.createAnalyser();
      this.inputAnalyser.fftSize = 128;

      // Script processor node for real-time buffer streaming
      this.scriptProcessor = this.inputAudioCtx.createScriptProcessor(2048, 1, 1);

      this.micSource.connect(this.inputAnalyser);
      this.inputAnalyser.connect(this.scriptProcessor);
      this.scriptProcessor.connect(this.inputAudioCtx.destination);

      this.scriptProcessor.onaudioprocess = (e) => {
        const floatArray = e.inputBuffer.getChannelData(0);

        // Convert Float32Array to PCM 16-bit Int16Array
        const pcm16 = new Int16Array(floatArray.length);
        for (let i = 0; i < floatArray.length; i++) {
          const s = Math.max(-1, Math.min(1, floatArray[i]));
          pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
        }

        // Convert Int16Array buffer to binary base64
        const bytes = new Uint8Array(pcm16.buffer);
        let binary = "";
        const chunkSize = 8192;
        for (let i = 0; i < bytes.byteLength; i += chunkSize) {
          const chunk = bytes.subarray(i, i + chunkSize);
          binary += String.fromCharCode.apply(null, chunk as any);
        }
        const base64 = btoa(binary);

        this.onInputAudio(base64);
      };

      // Proactively ensure context is running
      if (this.inputAudioCtx.state === "suspended") {
        await this.inputAudioCtx.resume();
      }

      console.log("Microphone capture started successfully at 16kHz");
    } catch (err) {
      console.error("Failed to start microphone recording:", err);
      throw err;
    }
  }

  /**
   * Stop recording microphone and clean up nodes.
   */
  public stopRecording() {
    if (this.scriptProcessor) {
      try {
        this.scriptProcessor.disconnect();
      } catch (_) {}
      this.scriptProcessor = null;
    }
    if (this.micSource) {
      try {
        this.micSource.disconnect();
      } catch (_) {}
      this.micSource = null;
    }
    if (this.micStream) {
      try {
        this.micStream.getTracks().forEach((track) => track.stop());
      } catch (_) {}
      this.micStream = null;
    }
    if (this.inputAudioCtx) {
      try {
        this.inputAudioCtx.close();
      } catch (_) {}
      this.inputAudioCtx = null;
    }
    this.inputAnalyser = null;
  }

  /**
   * Play base64-encoded PCM16 audio chunks at 24kHz using high-precision Web Audio timeline scheduling.
   */
  public playAudioChunk(base64PCM16: string) {
    try {
      if (!this.outputAudioCtx) {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        this.outputAudioCtx = new AudioContextClass({ sampleRate: 24000 });

        // Auto-resume if browser suspends playback AudioContext
        this.outputAudioCtx.onstatechange = () => {
          if (this.outputAudioCtx && this.outputAudioCtx.state === "suspended") {
            console.warn("Playback AudioContext suspended. Auto-resuming...");
            this.outputAudioCtx.resume().catch((err) => console.error("Failed to auto-resume output context:", err));
          }
        };

        this.outputAnalyser = this.outputAudioCtx.createAnalyser();
        this.outputAnalyser.fftSize = 128;
        this.outputAnalyser.connect(this.outputAudioCtx.destination);
        this.nextPlayTime = this.outputAudioCtx.currentTime;
      }

      // Resume context if suspended
      if (this.outputAudioCtx.state === "suspended") {
        this.outputAudioCtx.resume().catch((err) => console.error("Failed to resume output context:", err));
      }

      // Convert Base64 to ArrayBuffer
      const binaryString = atob(base64PCM16);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      const pcm16 = new Int16Array(bytes.buffer);
      const float32 = new Float32Array(pcm16.length);

      // Convert PCM16 integer to Float32 [-1.0, 1.0]
      for (let i = 0; i < pcm16.length; i++) {
        float32[i] = pcm16[i] / 32768.0;
      }

      const audioBuffer = this.outputAudioCtx.createBuffer(1, float32.length, 24000);
      audioBuffer.copyToChannel(float32, 0);

      const sourceNode = this.outputAudioCtx.createBufferSource();
      sourceNode.buffer = audioBuffer;

      // Connect source to analyser for output waveform telemetry
      if (this.outputAnalyser) {
        sourceNode.connect(this.outputAnalyser);
      } else {
        sourceNode.connect(this.outputAudioCtx.destination);
      }

      // Determine precise start time
      let playTime = this.outputAudioCtx.currentTime;
      if (this.nextPlayTime > playTime) {
        playTime = this.nextPlayTime;
      } else {
        // Offset slightly to account for network buffer timing
        playTime = playTime + 0.05;
      }

      sourceNode.start(playTime);
      this.nextPlayTime = playTime + audioBuffer.duration;

      this.scheduledSources.push(sourceNode);

      sourceNode.onended = () => {
        this.scheduledSources = this.scheduledSources.filter((s) => s !== sourceNode);
      };
    } catch (err) {
      console.error("Error playing back audio chunk:", err);
    }
  }

  /**
   * Proactively validate and resume both input and output audio contexts.
   * Extremely helpful for browser-imposed security or focus-shift suspensions.
   */
  public async resumeAudioContexts() {
    try {
      console.log("Sensing neural audio contexts. Resolving any browser suspension...");
      if (this.inputAudioCtx && this.inputAudioCtx.state === "suspended") {
        console.log("Resuming suspended inputAudioCtx...");
        await this.inputAudioCtx.resume();
      }
      if (this.outputAudioCtx && this.outputAudioCtx.state === "suspended") {
        console.log("Resuming suspended outputAudioCtx...");
        await this.outputAudioCtx.resume();
      }
    } catch (err) {
      console.error("Failed to proactively resume audio contexts:", err);
    }
  }

  /**
   * Stop all scheduled and actively playing audio sources (interruption).
   */
  public handleInterruption() {
    console.log("Interrupting output: flushing scheduled audio queues");
    this.scheduledSources.forEach((source) => {
      try {
        source.stop();
      } catch (_) {}
    });
    this.scheduledSources = [];
    if (this.outputAudioCtx) {
      this.nextPlayTime = this.outputAudioCtx.currentTime + 0.05;
    } else {
      this.nextPlayTime = 0;
    }
  }

  /**
   * Fetch live mic input audio levels (amplitude/energy).
   */
  public getInputVolume(): number {
    if (!this.inputAnalyser) return 0;
    const bufferLength = this.inputAnalyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    this.inputAnalyser.getByteFrequencyData(dataArray);

    let sum = 0;
    for (let i = 0; i < bufferLength; i++) {
      sum += dataArray[i];
    }
    return sum / bufferLength / 255; // Range [0.0, 1.0]
  }

  /**
   * Fetch live speaker output audio levels (amplitude/energy).
   */
  public getOutputVolume(): number {
    if (!this.outputAnalyser) return 0;
    const bufferLength = this.outputAnalyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    this.outputAnalyser.getByteFrequencyData(dataArray);

    let sum = 0;
    for (let i = 0; i < bufferLength; i++) {
      sum += dataArray[i];
    }
    return sum / bufferLength / 255; // Range [0.0, 1.0]
  }

  /**
   * Fully teardown audio capture and playback channels.
   */
  public destroy() {
    this.stopRecording();
    this.handleInterruption();
    if (this.outputAudioCtx) {
      try {
        this.outputAudioCtx.close();
      } catch (_) {}
      this.outputAudioCtx = null;
    }
    this.outputAnalyser = null;
  }
}
