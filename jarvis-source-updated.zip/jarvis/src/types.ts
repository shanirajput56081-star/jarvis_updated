export type ConnectionStatus = "disconnected" | "connecting" | "connected" | "error";

export type AssistantState = "idle" | "connecting" | "listening" | "speaking";

export interface LogEntry {
  id: string;
  time: string;
  type: "user" | "assistant" | "system" | "tool";
  message: string;
  meta?: any;
}
