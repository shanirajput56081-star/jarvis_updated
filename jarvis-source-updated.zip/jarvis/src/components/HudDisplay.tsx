import React from "react";
import { ConnectionStatus, AssistantState } from "../types";
import { Shield, Cpu, Activity, Terminal, Globe, ExternalLink } from "lucide-react";

interface HudDisplayProps {
  status: ConnectionStatus;
  state: AssistantState;
  lastOpenedUrl: { url: string; siteName: string; id: string } | null;
}

export const HudDisplay: React.FC<HudDisplayProps> = ({
  status,
  state,
  lastOpenedUrl,
}) => {
  return (
    <div className="w-full flex flex-col gap-6 font-mono text-xs text-sky-400" id="jarvis-hud-display">
      {/* Dynamic Grid Overlay (Background) */}
      <div className="fixed inset-0 bg-[linear-gradient(rgba(0,217,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,217,255,0.03)_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none -z-10" />

      {/* Futuristic Telemetry HUD Ribbon */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 border border-sky-500/20 bg-slate-950/40 backdrop-blur-md p-4 rounded-lg relative overflow-hidden" id="hud-telemetry-ribbon">
        {/* Futuristic corner brackets */}
        <div className="absolute top-0 left-0 w-2 h-2 border-t-2 border-l-2 border-cyan-400" />
        <div className="absolute top-0 right-0 w-2 h-2 border-t-2 border-r-2 border-cyan-400" />
        <div className="absolute bottom-0 left-0 w-2 h-2 border-b-2 border-l-2 border-cyan-400" />
        <div className="absolute bottom-0 right-0 w-2 h-2 border-b-2 border-r-2 border-cyan-400" />

        {/* Telemetry Item 1 */}
        <div className="flex items-center gap-3 border-r border-sky-500/10 last:border-0 pr-2">
          <Shield className="w-5 h-5 text-cyan-400 animate-pulse" />
          <div>
            <div className="text-[10px] text-slate-500 uppercase tracking-wider">Secure Protocol</div>
            <div className="font-semibold text-slate-200 uppercase">JARVIS-BIDI v3.1</div>
          </div>
        </div>

        {/* Telemetry Item 2 */}
        <div className="flex items-center gap-3 border-r border-sky-500/10 last:border-0 pr-2">
          <Activity className="w-5 h-5 text-cyan-400" />
          <div>
            <div className="text-[10px] text-slate-500 uppercase tracking-wider">Access Node</div>
            <div className="font-semibold text-cyan-300">ALLIN1DEVELOPERS Boss</div>
          </div>
        </div>

        {/* Telemetry Item 3 */}
        <div className="flex items-center gap-3 border-r border-sky-500/10 last:border-0 pr-2">
          <Cpu className="w-5 h-5 text-sky-400" />
          <div>
            <div className="text-[10px] text-slate-500 uppercase tracking-wider">Active Tools</div>
            <div className="font-semibold text-emerald-400 uppercase tracking-tight">openWebsite [Armed]</div>
          </div>
        </div>

        {/* Telemetry Item 4 */}
        <div className="flex items-center gap-3">
          <Terminal className="w-5 h-5 text-sky-400" />
          <div>
            <div className="text-[10px] text-slate-500 uppercase tracking-wider">Status Index</div>
            <div className="font-semibold text-sky-300 uppercase">
              {status === "connected" ? `${state}` : `${status}`}
            </div>
          </div>
        </div>
      </div>

      {/* Website Opener HUD Notification (Iframe / Popup Recovery Panel) */}
      {lastOpenedUrl && (
        <div className="border-2 border-emerald-500/30 bg-emerald-950/20 backdrop-blur-md p-4 rounded-lg relative flex flex-col sm:flex-row sm:items-center justify-between gap-4 animate-bounce" id="web-opener-panel">
          {/* Futuristic corner brackets */}
          <div className="absolute top-0 left-0 w-2 h-2 border-t-2 border-l-2 border-emerald-400" />
          <div className="absolute top-0 right-0 w-2 h-2 border-t-2 border-r-2 border-emerald-400" />
          <div className="absolute bottom-0 left-0 w-2 h-2 border-b-2 border-l-2 border-emerald-400" />
          <div className="absolute bottom-0 right-0 w-2 h-2 border-b-2 border-r-2 border-emerald-400" />

          <div className="flex items-center gap-3">
            <Globe className="w-6 h-6 text-emerald-400 animate-spin" />
            <div>
              <div className="text-[10px] text-emerald-300 uppercase font-bold tracking-wider">Website Request Executed</div>
              <div className="text-sm font-semibold text-slate-100">
                Opening <span className="text-emerald-400 font-bold">{lastOpenedUrl.siteName || "URL"}</span>
              </div>
              <div className="text-[10px] text-slate-400 break-all select-all">{lastOpenedUrl.url}</div>
            </div>
          </div>

          <a
            href={lastOpenedUrl.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 hover:text-black font-semibold rounded-md border border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.4)] transition-all cursor-pointer self-start sm:self-auto"
            id="hud-manual-open-button"
          >
            <span>Click to Open Site</span>
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      )}
    </div>
  );
};
