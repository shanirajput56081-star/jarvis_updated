import React from "react";
import { motion } from "motion/react";
import { AssistantState, ConnectionStatus } from "../types";

interface JarvisCoreProps {
  status: ConnectionStatus;
  state: AssistantState;
  onClick: () => void;
  audioEnergy: number; // Value between 0.0 and 1.0 (live level)
}

export const JarvisCore: React.FC<JarvisCoreProps> = ({
  status,
  state,
  onClick,
  audioEnergy,
}) => {
  // Determine color accents based on current state
  const isError = status === "error";
  const isConnecting = status === "connecting" || state === "connecting";
  const isListening = state === "listening";
  const isSpeaking = state === "speaking";
  const isDisconnected = status === "disconnected";

  // Pulse rate and glow size based on energy
  const speakScale = 1.0 + audioEnergy * 0.4;
  const speakGlow = 10 + audioEnergy * 40;

  return (
    <div className="relative flex flex-col items-center justify-center p-8 select-none" id="jarvis-core-container">
      {/* Glow Backdrop */}
      <motion.div
        className="absolute w-[280px] h-[280px] rounded-full blur-[100px] pointer-events-none"
        style={{
          background: isDisconnected
            ? "radial-gradient(circle, rgba(15, 23, 42, 0.4) 0%, rgba(0, 0, 0, 0) 70%)"
            : isError
            ? "radial-gradient(circle, rgba(239, 68, 68, 0.25) 0%, rgba(0, 0, 0, 0) 70%)"
            : isConnecting
            ? "radial-gradient(circle, rgba(6, 182, 212, 0.2) 0%, rgba(0, 0, 0, 0) 70%)"
            : isListening
            ? "radial-gradient(circle, rgba(14, 165, 233, 0.3) 0%, rgba(0, 0, 0, 0) 70%)"
            : `radial-gradient(circle, rgba(0, 217, 255, ${0.25 + audioEnergy * 0.45}) 0%, rgba(0, 0, 0, 0) 70%)`,
        }}
        animate={{
          scale: isSpeaking ? [1, 1.15, 1] : [1, 1.05, 1],
        }}
        transition={{
          repeat: Infinity,
          duration: isListening ? 1.5 : isSpeaking ? 0.6 : 3,
          ease: "easeInOut",
        }}
      />

      {/* Main Core Ring Wrapper */}
      <div className="relative flex items-center justify-center w-[300px] h-[300px]">
        {/* Concentric Design Inset Borders from Geometric Balance HTML */}
        <div className="absolute -inset-10 border border-sky-950/40 rounded-full pointer-events-none" />
        <div className="absolute -inset-20 border border-sky-950/25 rounded-full pointer-events-none" />

        {/* Ring 3 (Outer Dash Tracker Ring) */}
        <motion.div
          className={`absolute w-full h-full rounded-full border border-dashed ${
            isDisconnected
              ? "border-slate-800"
              : isError
              ? "border-red-500/30"
              : "border-cyan-400/30"
          }`}
          animate={{
            rotate: isDisconnected ? 0 : 360,
          }}
          transition={{
            repeat: Infinity,
            duration: isConnecting ? 10 : 30,
            ease: "linear",
          }}
        />

        {/* Ring 2 (Middle Precision HUD Markings with Neon Glow from Design HTML) */}
        <motion.div
          className={`absolute w-[85%] h-[85%] rounded-full border-2 ${
            isDisconnected
              ? "border-slate-800/60"
              : isError
              ? "border-red-500/40"
              : "border-[var(--neon-blue)]"
          } flex items-center justify-center`}
          style={{
            borderLeftColor: "transparent",
            borderRightColor: "transparent",
            boxShadow: isDisconnected ? "none" : "0 0 15px var(--glow-blue)",
          }}
          animate={{
            rotate: isDisconnected ? 0 : -360,
          }}
          transition={{
            repeat: Infinity,
            duration: isConnecting ? 5 : 20,
            ease: "linear",
          }}
        />

        {/* Ring 1 (Inner Scan Tracker / Active Rippler) */}
        <motion.div
          className={`absolute w-[72%] h-[72%] rounded-full border ${
            isDisconnected
              ? "border-slate-800/40"
              : isError
              ? "border-red-500/50"
              : isConnecting
              ? "border-[var(--neon-blue)] border-t-transparent border-b-transparent"
              : "border-sky-400/50"
          }`}
          animate={
            isDisconnected
              ? { scale: 1, rotate: 0 }
              : isConnecting
              ? { rotate: 360, scale: [1, 1.02, 1] }
              : isListening
              ? { scale: [1, 1.08, 1], rotate: 45 }
              : isSpeaking
              ? { scale: [1, 1.03 + audioEnergy * 0.08, 1], rotate: -45 }
              : { scale: [1, 1.02, 1], rotate: 0 }
          }
          transition={{
            repeat: Infinity,
            duration: isConnecting ? 2 : 4,
            ease: "easeInOut",
          }}
        />

        {/* Listening Ripple Wave Outwards */}
        {isListening && (
          <>
            <motion.div
              className="absolute w-[60%] h-[60%] rounded-full border border-sky-400/80 pointer-events-none"
              initial={{ scale: 0.9, opacity: 0.8 }}
              animate={{ scale: 1.5, opacity: 0 }}
              transition={{ repeat: Infinity, duration: 1.6, ease: "easeOut" }}
            />
            <motion.div
              className="absolute w-[60%] h-[60%] rounded-full border border-cyan-400/50 pointer-events-none"
              initial={{ scale: 0.9, opacity: 0.8 }}
              animate={{ scale: 1.8, opacity: 0 }}
              transition={{ repeat: Infinity, duration: 1.6, delay: 0.8, ease: "easeOut" }}
            />
          </>
        )}

        {/* Main Central Orb (Interactive Click Trigger) */}
        <motion.button
          onClick={onClick}
          className="z-10 relative flex items-center justify-center w-[52%] h-[52%] rounded-full cursor-pointer focus:outline-none"
          id="jarvis-power-button"
          whileHover={{ scale: isDisconnected ? 1.05 : 0.98 }}
          whileTap={{ scale: 0.95 }}
          animate={{
            scale: isSpeaking ? speakScale : 1.0,
          }}
          transition={{
            type: "spring",
            stiffness: 300,
            damping: 15,
          }}
        >
          {/* Outer Ring Glass Layer */}
          <div
            className={`absolute inset-0 rounded-full transition-all duration-500 border-2 ${
              isDisconnected
                ? "bg-slate-900/80 border-slate-700/60 shadow-inner"
                : isError
                ? "bg-red-950/40 border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.3)]"
                : isConnecting
                ? "bg-cyan-950/40 border-[var(--neon-blue)] shadow-[0_0_20px_rgba(6,182,212,0.4)]"
                : "bg-slate-950/70 border-sky-400 shadow-[0_0_25px_rgba(0,217,255,0.3)]"
            }`}
          />

          {/* Core Electric Glow Center */}
          <motion.div
            className={`absolute w-[75%] h-[75%] rounded-full transition-all duration-500 flex flex-col items-center justify-center ${
              isDisconnected
                ? "bg-slate-800/50 shadow-none"
                : isError
                ? "bg-red-900/60 shadow-[0_0_20px_#ef4444]"
                : isConnecting
                ? "bg-cyan-800/70"
                : "bg-sky-500/40"
            }`}
            style={{
              boxShadow: isDisconnected
                ? "none"
                : isError
                ? "0 0 25px rgba(239,68,68,0.8), inset 0 0 10px rgba(255,255,255,0.2)"
                : isConnecting
                ? "0 0 30px rgba(6,182,212,0.9), inset 0 0 12px rgba(255,255,255,0.4)"
                : `0 0 ${speakGlow}px rgba(0, 217, 255, 0.95), inset 0 0 15px rgba(255,255,255,0.5)`,
              background: isDisconnected
                ? ""
                : isError
                ? ""
                : "radial-gradient(circle, var(--neon-blue) 0%, #0369a1 70%, var(--deep-navy) 100%)"
            }}
            animate={
              isDisconnected
                ? { opacity: 0.4 }
                : isConnecting
                ? { opacity: [0.6, 1, 0.6] }
                : isListening
                ? { scale: [0.95, 1.05, 0.95] }
                : { scale: 1 }
            }
            transition={{
              repeat: Infinity,
              duration: isConnecting ? 1 : isListening ? 2 : 3,
              ease: "easeInOut",
            }}
          >
            {/* Holographic HUD Core Icon / Micro-Patterns */}
            <div className="absolute inset-0 rounded-full bg-[radial-gradient(transparent_45%,rgba(0,217,255,0.1)_50%)] bg-[size:6px_6px]" />

            {/* Micro Power Core Signet */}
            <svg
              className={`w-10 h-10 transition-colors duration-500 ${
                isDisconnected
                  ? "text-slate-600"
                  : isError
                  ? "text-red-200"
                  : "text-white"
              }`}
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              {isDisconnected ? (
                // Standby Power Symbol
                <path d="M18.36 6.64a9 9 0 1 1-12.73 0M12 2v10" />
              ) : isConnecting ? (
                // Circular loading gap
                <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" />
              ) : isListening ? (
                // Mic Icon
                <>
                  <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z" />
                  <path d="M19 10v2a7 7 0 0 1-14 0v-2M12 19v3M8 22h8" />
                </>
              ) : (
                // Waveforms / Active Speaking state or general power
                <path d="M12 2v20M17 5v14M7 5v14M22 9v6M2 9v6" />
              )}
            </svg>
          </motion.div>
        </motion.button>
      </div>

      {/* Dynamic Geometric Audio Waveform Visualizer */}
      <div className="flex items-center gap-1 h-[60px] mt-6 select-none" id="hud-waveform-bars">
        {[20, 40, 55, 30, 45, 60, 35, 25].map((baseHeight, idx) => {
          // Dynamic height calculated based on audioEnergy and state
          const isActive = isListening || isSpeaking;
          const energyMultiplier = isActive ? (0.2 + audioEnergy * 1.1) : 0.08;
          // Add dynamic sine offsets
          const phaseOffset = Math.sin((idx * 0.8) + (Date.now() / 150)) * 0.15;
          const height = isActive
            ? Math.max(4, Math.min(60, baseHeight * (energyMultiplier + phaseOffset)))
            : 4;

          return (
            <motion.div
              key={idx}
              className="w-1.5 rounded-[2px] transition-all duration-75"
              style={{
                height: `${height}px`,
                backgroundColor: isDisconnected
                  ? "#334155"
                  : isError
                  ? "#ef4444"
                  : "var(--neon-blue)",
                boxShadow: isDisconnected
                  ? "none"
                  : isError
                  ? "0 0 6px #ef4444"
                  : "0 0 8px var(--neon-blue)",
              }}
              animate={isActive ? {} : { scaleY: 1 }}
            />
          );
        })}
      </div>

      {/* State Display Text */}
      <div className="mt-8 flex flex-col items-center gap-1.5" id="jarvis-state-label">
        <motion.span
          className={`font-mono text-xs tracking-[0.25em] uppercase font-semibold ${
            isDisconnected
              ? "text-slate-500"
              : isError
              ? "text-red-400"
              : isConnecting
              ? "text-cyan-400"
              : isListening
              ? "text-sky-400"
              : "text-emerald-400"
          }`}
          key={state + status}
          initial={{ opacity: 0, y: 5 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          {isDisconnected
            ? "STANDBY MODE"
            : isError
            ? "CORE ERROR"
            : isConnecting
            ? "BOOTING CONFLICT BRIDGE..."
            : isListening
            ? "LISTENING TO BOSS..."
            : "SPEAKING..."}
        </motion.span>

        {/* Pulsing state dots */}
        <div className="flex gap-1.5 mt-1" id="hud-pulse-dots">
          <span
            className={`w-1.5 h-1.5 rounded-full ${
              isDisconnected
                ? "bg-slate-700"
                : isError
                ? "bg-red-500 animate-ping"
                : isConnecting
                ? "bg-cyan-400 animate-pulse"
                : isListening
                ? "bg-sky-400 animate-bounce"
                : "bg-emerald-400 animate-ping"
            }`}
          />
          <span
            className={`w-1.5 h-1.5 rounded-full ${
              isDisconnected
                ? "bg-slate-700"
                : isError
                ? "bg-red-500/50"
                : isConnecting
                ? "bg-cyan-400/50 animate-pulse delay-100"
                : isListening
                ? "bg-sky-400 animate-bounce delay-100"
                : "bg-emerald-400/60 animate-ping delay-75"
            }`}
          />
          <span
            className={`w-1.5 h-1.5 rounded-full ${
              isDisconnected
                ? "bg-slate-700"
                : isError
                ? "bg-red-500/20"
                : isConnecting
                ? "bg-cyan-400/30 animate-pulse delay-200"
                : isListening
                ? "bg-sky-400 animate-bounce delay-200"
                : "bg-emerald-400/30 animate-ping delay-150"
            }`}
          />
        </div>
      </div>
    </div>
  );
};
